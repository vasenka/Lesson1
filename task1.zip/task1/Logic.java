package javase01.t01.logic;

public class Logic {
public String method(){
return"I am string in Logic.";
}

}
